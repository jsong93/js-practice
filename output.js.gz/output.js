import { name, sayHello } from './es6.js';

// jsong
console.log(name);
// hello jsong
sayHello();
